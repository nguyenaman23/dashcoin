<?php

$device_id = "xxx";

$userOemail = "xxx";

$passcode = "xxx";

?>